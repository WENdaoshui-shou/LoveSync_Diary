create definer = liutao@localhost view `1` as
select `subquery`.`id_column` AS `id_column`, `subquery`.`Column2` AS `Column2`
from (select `yt`.`id_column`                                                             AS `id_column`,
             `tc`.`Column2`                                                               AS `Column2`,
             row_number() OVER (PARTITION BY `yt`.`id_column` ORDER BY `yt`.`id_column` ) AS `rn`
      from (`excel`.`your_table` `yt` left join `excel`.`table_copy1` `tc`
            on ((`yt`.`id_column` = `tc`.`Column1`)))) `subquery`
where (`subquery`.`rn` = 1)
order by (`subquery`.`id_column` collate utf8mb4_general_ci);

